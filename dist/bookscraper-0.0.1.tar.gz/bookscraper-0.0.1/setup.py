from setuptools import setup

setup(
    name='bookscraper',
    version='0.0.1',
    description='scrape books information from pdfdrive',
    py_modules=["bookscraper"],
    package_dir={'':'src'},
)
